# Author: Seb Blair
# Date Created: 10/09/2021
# Version: 1.0

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.offsetbox as obox
# colour wheel for accessibilty
line='black'
startColour=['blue','blue','teal','green']
stopColour=['gold','gold','fuchsia','red']

# select correct index for accessibilty colours used in plot xtickslabels and xlabels
def colourscheme(accessibilty):
    colourIndex = [s for s, scheme in enumerate(accessibilty) if scheme]
    return colourIndex[0]
 
# conversts the string to ASCII to binary
def binary_data(name):
    data = list(map(int,''.join(format(ord(b), '08b') for b in name)))
    temp =[0]* len(data)
    for x in range(len(data)):
        if data[x] == 1:
            temp[x] = 1
        else: 
            temp[x] = 0
    return temp

# pads the binary of the ASCII code with start and stop bits
def transmission(data):
    first = True;
    txData= [];
    for i , element in enumerate(data):
        if i % 8 == 0:
            if first:
                txData.append(1)
                first = False
            else:
                txData.append(1)
                txData.append(1)
        txData.append(element)
        if i == len(data)-1:
            txData.append(1)
    return txData

# colours first bit on xlable to identify the start of each 8 bits, one colour from accessibility options
def start(ax, colour):
    xbox = obox.TextArea("Data ",textprops=dict(color="black", size=15,ha='left',va='bottom'))
    xbox2 = obox.TextArea("START ",textprops=dict(color=colour, size=15,ha='left',va='bottom'))
    xbox3 = obox.TextArea("bit ",textprops=dict(color="black", size=15,ha='left',va='bottom'))
    xbox = obox.HPacker(children=[xbox, xbox2, xbox3],align="bottom", pad=0, sep=5)
    anchored_xbox = obox.AnchoredOffsetbox(loc=10, child=xbox, pad=0., frameon=False, bbox_to_anchor=(0.5, -0.5), bbox_transform=ax.transAxes, borderpad=0.)
    return anchored_xbox

# colours the start and stop bits for data stream. two colours from accessibilty options
def startstop(ax, colour1, colour2):
    xbox = obox.TextArea("Data ",textprops=dict(color="black", size=15,ha='left',va='bottom'))
    xbox2 = obox.TextArea("START ",textprops=dict(color=colour1, size=15,ha='left',va='bottom'))
    xbox3 = obox.TextArea("and ",textprops=dict(color="black", size=15,ha='left',va='bottom'))
    xbox4 = obox.TextArea("STOP ",textprops=dict(color=colour2, size=15,ha='left',va='bottom'))
    xbox5 = obox.TextArea("bits ",textprops=dict(color="black", size=15,ha='left',va='bottom'))
    xbox = obox.HPacker(children=[xbox, xbox2, xbox3,xbox4,xbox5],align="bottom", pad=0, sep=5)
    anchored_xbox = obox.AnchoredOffsetbox(loc=10, child=xbox, pad=0., frameon=False, bbox_to_anchor=(0.5, -0.5), bbox_transform=ax.transAxes, borderpad=0.)
    return anchored_xbox

# Handles all the plot functionality, data, tx<True,False> for start stop bits plotting, and accessibilty for colour blindness
def plot(data,tx,accessibilty):
    size=len(data)
    xaxis = list(range(0,len(data)))
    yaxis = np.array(data)
    ax=plt.axes()
    plt.step(xaxis, yaxis, color=line)
    plt.grid(axis = 'x',which ='major')
    ax.set_yticks([0,1])
    ax.set_xticks(range(max(xaxis)+1))
    ax.set_xticklabels([str(d) for d in data], fontsize=15)
    plt.rcParams['figure.figsize'] = [(size/2), 2]
    if not tx:
        for i in range(len(data)):
            if i % 8 ==0:
                plt.gca().get_xticklabels()[i].set_color(startColour[colourscheme(accessibilty)])
                ax.add_artist(start(ax,startColour[colourscheme(accessibilty)]))
    else:
        for i in range(len(data)):
            if i % 10 == 0:
                plt.gca().get_xticklabels()[i].set_color(startColour[colourscheme(accessibilty)])
            elif i % 10 == 9:
                plt.gca().get_xticklabels()[i].set_color(stopColour[colourscheme(accessibilty)])
        ax.add_artist(startstop(ax,startColour[colourscheme(accessibilty)],stopColour[colourscheme(accessibilty)]))
    plt.show()
    
# shows just the signal of the ASCII character
def run(name,accessibilty):
    if len(name) > 0:
        binData = binary_data(name)
        plot(binData,False,accessibilty)
    else:
        print("Did you assign a letter to the variable 'name'?")
    
    
# shows the ASCII with start and stop bits    
def runtx(name,accessibilty):
    if len(name) > 0:
        binData = binary_data(name)
        tBinData = transmission(binData)
        plot(tBinData,True,accessibilty)
    else:
        print("Did you assign a letter to the variable 'name'?")
        
#checks to see if the correct answer is supplied against the question asked
# the true answer is encrypted to stop the snoopers :)
def check(Q,A):
    if not len(A)  > 0:
        print('Did you put your answer in the second expected argument of check(Q,"YOURANSWER")')
    elif A == 'YOURANSWER':
        print('Change the placeholder value <YOURANSWER> to your answer')
    elif Q == 1:
        if secrets(A) == '753c3a3c3f1c5d56273f53b2432':
            print("Correct, the answer is the ",A)
        else:
            print("Incorrect: \n * did check you which way the data is being read? \n * double check your maths \n * could the answer be case sensitive?")
    elif Q == 2:
        if secrets(A) == 'c3e65353b23153633b35217f2c':
            print("Correct, you have got mad",A,"!")
        else:
            print("Incorrect: \n * did check you which way the data is being read? \n * double check your maths \n * could the answer be case sensitive? \n * think beyond the alphabet..hmm?")
    elif Q == "3a":
        if secrets(A) =='97b667c777e6d62697b677a69':
            print("Correct, the answer is 0.25s")
        else:
            print("Incorrect: \n * double check your maths \n * remember f = 1/h")
    elif Q == "3b":
        if secrets(A) =='b60647b72606d62757c627872':
            print("Correct, the answer is 250us")
        else:
            print("Incorrect: \n * double check your maths \n * have you converted to microseconds?")      
    elif Q == "3c":
        if secrets(A) =='b60647b72606d62757c627872':
            print("Correct, the answer is 250ns")
        else:
            print("Incorrect: \n * double check your maths \n * have you converted to nanoseconds?")    
    elif Q == "3d":
        if secrets(A) =='8656478776058627679627b77':
            print("Correct, the answer is 100ps")
        else:
            print("Incorrect: \n * double check your maths \n * have you converted to picoseconds?") 
    elif Q == "4a":
        if secrets(A) =='5d31302d2334505c36232d362e23':
            print("Correct, the answer is d) 10101010. An even number of ones supplied." )
        else:
            print("Incorrect: \n * double check the number of ones") 
    elif Q == "4b":
        if secrets(A) =='5a36372a2433575b31242a312924':
            print("Correct, the answer is c) 10100001. An odd number of ones supplied." )
        else:
            print("Incorrect: \n * double check the number of zeros") 
                       
# returns: Encrypts the supplied answer
def secrets(a):
    xored = []
    b = '9UTIGP48RGIRJG'
    for i in range(max(len(a), len(b))):
        xored_value = ord(a[i%len(a)]) ^ ord(b[i%len(b)])
        xored.append(hex(xored_value)[2:])
    return ''.join(xored)